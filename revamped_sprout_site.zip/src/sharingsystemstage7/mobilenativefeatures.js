// Mobile-specific functionality
const mobileFeatures = {
    
    // Native sharing via Web Share API
    nativeShare: async (courseData, trackingLink) => {
        if (navigator.share) {
            try {
                await navigator.share({
                    title: `${courseData.title} - University of Bacon`,
                    text: `Found this great ${courseData.category} deal! 🥓`,
                    url: trackingLink
                });
                
                // Track native share
                trackEvent('native_share_used', {
                    courseId: courseData.id,
                    platform: 'native'
                });
            } catch (error) {
                console.error('Native share failed:', error);
                fallbackShare(courseData, trackingLink);
            }
        } else {
            fallbackShare(courseData, trackingLink);
        }
    },
    
    // Contact picker for direct sharing
    shareViaContacts: async (shareLink) => {
        if ('contacts' in navigator && 'ContactsManager' in window) {
            try {
                const contacts = await navigator.contacts.select(['name', 'email'], { multiple: true });
                
                // Create email share for selected contacts
                const emailContent = generateEmailContent(shareLink);
                
                contacts.forEach(contact => {
                    sendEmailShare(contact.email, emailContent);
                });
                
            } catch (error) {
                console.error('Contact picker failed:', error);
            }
        }
    },
    
    // Camera integration for custom images
    captureCustomImage: async () => {
        if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
            try {
                const stream = await navigator.mediaDevices.getUserMedia({
                    video: { facingMode: 'environment' }
                });
                
                // Show camera interface
                showCameraInterface(stream);
                
            } catch (error) {
                console.error('Camera access failed:', error);
                // Fallback to file upload
                showFileUpload();
            }
        }
    },
    
    // Offline support
    offlineQueueShare: (shareData) => {
        // Store share data for when online
        const offlineQueue = JSON.parse(localStorage.getItem('offlineShares') || '[]');
        offlineQueue.push({
            ...shareData,
            timestamp: new Date().toISOString(),
            id: generateUUID()
        });
        localStorage.setItem('offlineShares', JSON.stringify(offlineQueue));
        
        // Show offline notification
        showToast('Share saved! Will post when you\'re back online.', 'info');
    },
    
    // Process offline queue when online
    processOfflineQueue: async () => {
        const offlineQueue = JSON.parse(localStorage.getItem('offlineShares') || '[]');
        
        for (const shareData of offlineQueue) {
            try {
                await api.sharing.postToPlatform(shareData);
                
                // Remove from queue
                const updatedQueue = offlineQueue.filter(item => item.id !== shareData.id);
                localStorage.setItem('offlineShares', JSON.stringify(updatedQueue));
                
            } catch (error) {
                console.error('Failed to process offline share:', error);
            }
        }
    }
};

// Service Worker for offline functionality
const serviceWorkerCode = `
    self.addEventListener('sync', function(event) {
        if (event.tag === 'background-share') {
            event.waitUntil(processOfflineShares());
        }
    });
    
    async function processOfflineShares() {
        // Process queued shares when back online
        const offlineShares = await getOfflineShares();
        
        for (const share of offlineShares) {
            try {
                await fetch('/api/sharing/post-to-platform', {
                    method: 'POST',
                    body: JSON.stringify(share),
                    headers: {
                        'Content-Type': 'application/json'
                    }
                });
                
                await removeOfflineShare(share.id);
            } catch (error) {
                console.error('Background share failed:', error);
            }
        }
    }
`;
