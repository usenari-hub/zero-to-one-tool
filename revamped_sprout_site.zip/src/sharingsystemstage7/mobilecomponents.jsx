// Mobile Share Intent Modal
const MobileShareModal = ({ course, isOpen, onClose }) => {
    return (
        <div className={`mobile-share-modal ${isOpen ? 'active' : ''}`}>
            <div className="modal-backdrop" onClick={onClose} />
            <div className="modal-content">
                {/* Swipe indicator */}
                <div className="swipe-indicator" />
                
                {/* Course preview */}
                <div className="mobile-course-preview">
                    <img src={course.image} className="course-thumb" />
                    <div className="course-info">
                        <h3>{course.title}</h3>
                        <div className="earning-highlight">
                            🥓 Earn ${course.baconPotential}
                        </div>
                    </div>
                </div>
                
                {/* Quick share grid */}
                <div className="mobile-share-grid">
                    <button className="mobile-share-btn facebook" onClick={() => handleQuickShare('facebook')}>
                        <div className="btn-icon">📘</div>
                        <div className="btn-text">Facebook</div>
                    </button>
                    
                    <button className="mobile-share-btn twitter" onClick={() => handleQuickShare('twitter')}>
                        <div className="btn-icon">🐦</div>
                        <div className="btn-text">Twitter</div>
                    </button>
                    
                    <button className="mobile-share-btn instagram" onClick={() => handleQuickShare('instagram')}>
                        <div className="btn-icon">📸</div>
                        <div className="btn-text">Instagram</div>
                    </button>
                    
                    <button className="mobile-share-btn whatsapp" onClick={() => handleQuickShare('whatsapp')}>
                        <div className="btn-icon">💬</div>
                        <div className="btn-text">WhatsApp</div>
                    </button>
                    
                    <button className="mobile-share-btn sms" onClick={() => handleQuickShare('sms')}>
                        <div className="btn-icon">📱</div>
                        <div className="btn-text">Text</div>
                    </button>
                    
                    <button className="mobile-share-btn copy" onClick={() => handleCopyLink()}>
                        <div className="btn-icon">🔗</div>
                        <div className="btn-text">Copy Link</div>
                    </button>
                </div>
                
                {/* Advanced options */}
                <button className="advanced-share-btn" onClick={() => openShareTools()}>
                    🛠️ Advanced Sharing Tools
                </button>
            </div>
        </div>
    );
};

// Mobile Share Tools (Simplified)
const MobileShareTools = ({ shareLinkId }) => {
    const [selectedPlatform, setSelectedPlatform] = useState('facebook');
    const [content, setContent] = useState('');
    
    return (
        <div className="mobile-share-tools">
            {/* Platform tabs */}
            <div className="mobile-platform-tabs">
                {['facebook', 'twitter', 'instagram', 'whatsapp'].map(platform => (
                    <button
                        key={platform}
                        className={`platform-tab ${selectedPlatform === platform ? 'active' : ''}`}
                        onClick={() => setSelectedPlatform(platform)}
                    >
                        {getPlatformIcon(platform)}
                    </button>
                ))}
            </div>
            
            {/* Content editor */}
            <div className="mobile-content-editor">
                <textarea
                    value={content}
                    onChange={(e) => setContent(e.target.value)}
                    placeholder={`Write your ${selectedPlatform} post...`}
                    className="mobile-textarea"
                />
                
                <div className="editor-tools">
                    <button className="tool-btn">😊</button>
                    <button className="tool-btn">#️⃣</button>
                    <button className="tool-btn">📷</button>
                    <div className="char-count">{content.length}/500</div>
                </div>
            </div>
            
            {/* Quick preview */}
            <div className="mobile-preview">
                <div className="preview-header">👀 Preview</div>
                <div className="preview-content">
                    {content || "Your post preview will appear here..."}
                </div>
            </div>
            
            {/* Action buttons */}
            <div className="mobile-actions">
                <button className="post-btn primary" onClick={() => handlePost()}>
                    📤 Post Now
                </button>
                <button className="schedule-btn secondary" onClick={() => handleSchedule()}>
                    📅 Schedule
                </button>
            </div>
        </div>
    );
};
