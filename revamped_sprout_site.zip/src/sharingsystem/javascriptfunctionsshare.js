// Share modal management
function openShareModal(courseId) {
    const modal = document.getElementById('shareModal');
    modal.classList.add('active');
    
    // Load course data and update modal content
    loadCourseDataForSharing(courseId);
    
    // Track modal open event
    trackEvent('share_modal_opened', {
        courseId: courseId,
        timestamp: new Date().toISOString()
    });
}

function closeShareModal() {
    const modal = document.getElementById('shareModal');
    modal.classList.remove('active');
}

// Handle sharing method selection
async function initiateShare(courseId, method) {
    try {
        // Create share link in backend
        const shareLink = await createShareLink(courseId, method);
        
        // Redirect to appropriate sharing flow
        switch(method) {
            case 'social_media':
                redirectToSocialSharing(shareLink);
                break;
            case 'email':
                redirectToEmailSharing(shareLink);
                break;
            case 'sms':
                redirectToSMSSharing(shareLink);
                break;
            case 'copy_link':
                copyLinkToClipboard(shareLink);
                break;
        }
        
        // Close modal
        closeShareModal();
        
        // Show success message
        showSuccessToast('Share link created! Opening sharing tools...');
        
    } catch (error) {
        console.error('Error creating share link:', error);
        showErrorToast('Error creating share link. Please try again.');
    }
}

// API call to create tracked share link
async function createShareLink(courseId, method) {
    const response = await fetch('/api/sharing/create-link', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${getAuthToken()}`
        },
        body: JSON.stringify({
            courseId: courseId,
            sharingMethod: method,
            timestamp: new Date().toISOString()
        })
    });
    
    if (!response.ok) {
        throw new Error('Failed to create share link');
    }
    
    const data = await response.json();
    return data.shareLink;
}

// Quick share functions
async function quickShare(courseId, platform) {
    const shareLink = await createShareLink(courseId, 'social_media');
    
    // Generate platform-specific share URL
    const shareContent = await generatePlatformContent(courseId, platform);
    const platformURL = generatePlatformShareURL(platform, shareContent, shareLink);
    
    // Open in new window
    window.open(platformURL, '_blank', 'width=600,height=400');
    
    closeShareModal();
}
