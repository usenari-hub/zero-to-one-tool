// Main Sharing System Components
const SharingSystemComponents = {
    
    // Course Discovery & Intent
    'CourseCard': {
        props: ['course', 'onShareClick', 'onViewDetails'],
        features: [
            'Share button with bacon potential display',
            'Quick share options',
            'Performance indicators',
            'Responsive design'
        ]
    },
    
    'ShareIntentModal': {
        props: ['course', 'isOpen', 'onClose', 'onMethodSelect'],
        features: [
            'Platform selection grid',
            'Quick share buttons',
            'Earning potential calculator',
            'Method-specific guidance'
        ]
    },
    
    // Share Links Management
    'ShareLinksDashboard': {
        props: ['user'],
        state: ['shareLinks', 'filters', 'sorting', 'loading'],
        features: [
            'Grid/list view toggle',
            'Real-time stats cards',
            'Advanced filtering',
            'Search functionality',
            'Bulk operations'
        ]
    },
    
    'ShareLinkCard': {
        props: ['shareLink', 'onOpenTools', 'onViewAnalytics'],
        features: [
            'Performance indicators',
            'Quick actions menu',
            'Real-time click updates',
            'Chain status display'
        ]
    },
    
    // Share Tools Workspace
    'ShareToolsWorkspace': {
        props: ['shareLinkId'],
        state: ['courseData', 'selectedPlatform', 'content', 'templates'],
        features: [
            'Platform-specific editors',
            'Real-time preview',
            'Template system',
            'AI content suggestions',
            'Performance predictions'
        ]
    },
    
    'PlatformContentCreator': {
        props: ['platform', 'shareLink', 'onContentChange'],
        features: [
            'Platform-optimized editor',
            'Character count tracking',
            'Hashtag suggestions',
            'Image selector',
            'Audience targeting'
        ]
    },
    
    'ContentPreview': {
        props: ['platform', 'content', 'image', 'shareLink'],
        features: [
            'Real-time preview updates',
            'Platform-accurate rendering',
            'Performance predictions',
            'Optimization suggestions'
        ]
    },
    
    // Analytics Dashboard
    'AnalyticsDashboard': {
        props: ['shareLinkId', 'timeRange'],
        features: [
            'Interactive charts',
            'Real-time data updates',
            'Drill-down capabilities',
            'Export functionality',
            'AI insights integration'
        ]
    },
    
    'PerformanceCharts': {
        props: ['data', 'chartType', 'timeRange'],
        features: [
            'Multiple chart types',
            'Interactive tooltips',
            'Zoom and pan',
            'Data point selection'
        ]
    }
};
