// Sharing System Store
const sharingStore = {
    state: {
        // Share Links
        shareLinks: [],
        activeShareLink: null,
        shareLinksLoading: false,
        shareLinksError: null,
        
        // Share Tools
        shareToolsOpen: false,
        currentPlatform: 'facebook',
        contentDrafts: {},
        templates: {
            facebook: [],
            twitter: [],
            linkedin: [],
            email: [],
            sms: []
        },
        
        // Analytics
        analyticsData: {},
        analyticsLoading: false,
        selectedTimeRange: '7d',
        
        // UI State
        viewMode: 'grid', // grid or list
        filters: {
            status: 'all',
            platform: 'all',
            performance: 'all'
        },
        sorting: {
            field: 'created_at',
            direction: 'desc'
        }
    },
    
    actions: {
        // Share Links Management
        fetchShareLinks: async (filters, pagination) => {
            set(state => ({ shareLinksLoading: true }));
            try {
                const response = await api.sharing.getMyLinks(filters, pagination);
                set(state => ({
                    shareLinks: response.shareLinks,
                    shareLinksLoading: false,
                    shareLinksError: null
                }));
            } catch (error) {
                set(state => ({
                    shareLinksLoading: false,
                    shareLinksError: error.message
                }));
            }
        },
        
        createShareLink: async (courseId, method) => {
            const response = await api.sharing.createIntent({
                courseId,
                sharingMethod: method
            });
            
            // Add to share links
            set(state => ({
                shareLinks: [response, ...state.shareLinks]
            }));
            
            return response;
        },
        
        openShareTools: (shareLinkId) => {
            set(state => ({
                shareToolsOpen: true,
                activeShareLink: shareLinkId
            }));
        },
        
        closeShareTools: () => {
            set(state => ({
                shareToolsOpen: false,
                activeShareLink: null
            }));
        },
        
        // Content Creation
        updateContent: (platform, content) => {
            set(state => ({
                contentDrafts: {
                    ...state.contentDrafts,
                    [platform]: content
                }
            }));
        },
        
        saveContentDraft: async (shareLinkId, platform, content) => {
            await api.sharing.saveDraft({
                shareLinkId,
                platform,
                content
            });
        },
        
        postToSocialMedia: async (shareLinkId, platform, content, options) => {
            const response = await api.sharing.postToPlatform({
                shareLinkId,
                platform,
                content,
                ...options
            });
            
            // Update share link with new post
            set(state => ({
                shareLinks: state.shareLinks.map(link => 
                    link.id === shareLinkId 
                        ? { ...link, lastSharedAt: new Date() }
                        : link
                )
            }));
            
            return response;
        },
        
        // Analytics
        fetchAnalytics: async (shareLinkId, timeRange) => {
            set(state => ({ analyticsLoading: true }));
            try {
                const data = await api.sharing.getAnalytics(shareLinkId, { timeRange });
                set(state => ({
                    analyticsData: {
                        ...state.analyticsData,
                        [shareLinkId]: data
                    },
                    analyticsLoading: false
                }));
            } catch (error) {
                set(state => ({ analyticsLoading: false }));
            }
        },
        
        // Real-time Updates
        updateShareLinkStats: (shareLinkId, stats) => {
            set(state => ({
                shareLinks: state.shareLinks.map(link =>
                    link.id === shareLinkId
                        ? { ...link, ...stats }
                        : link
                )
            }));
        }
    }
};
