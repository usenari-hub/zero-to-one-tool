const shareLinksAPI = {
    // Get user's share links
    'GET /api/sharing/my-links': {
        description: 'Get all share links for authenticated user',
        parameters: {
            page: 'number',
            limit: 'number',
            filter: 'string (all|active|archived)',
            sort: 'string (newest|clicks|performance)',
            search: 'string'
        },
        response: {
            shareLinks: [],
            totalCount: 'number',
            stats: {
                totalLinks: 'number',
                totalClicks: 'number',
                pendingBacon: 'number',
                avgConversionRate: 'number'
            }
        }
    },
    
    // Create new share link
    'POST /api/sharing/create-link': {
        description: 'Create new tracked share link',
        body: {
            courseId: 'string',
            sharingMethod: 'string',
            customMessage: 'string (optional)'
        },
        response: {
            shareLinkId: 'string',
            trackingCode: 'string',
            shareUrl: 'string',
            expiresAt: 'datetime'
        }
    },
    
    // Get share link details
    'GET /api/sharing/links/:linkId': {
        description: 'Get detailed information for specific share link',
        response: {
            linkInfo: {},
            analytics: {},
            clickHistory: [],
            chainStatus: {}
        }
    },
    
    // Update share link
    'PUT /api/sharing/links/:linkId': {
        description: 'Update share link settings',
        body: {
            customMessage: 'string',
            isActive: 'boolean',
            expirationDate: 'datetime'
        }
    },
    
    // Archive share link
    'DELETE /api/sharing/links/:linkId': {
        description: 'Archive/deactivate share link'
    }
};
