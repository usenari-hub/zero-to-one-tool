// Share Tools Management
function openShareTools(shareLinkId) {
    // Load share link data
    loadShareLinkData(shareLinkId);
    
    // Show share tools workspace
    const workspace = document.getElementById('shareToolsWorkspace');
    workspace.classList.add('active');
    
    // Initialize content creators
    initializeContentCreators(shareLinkId);
    
    // Track workspace open
    trackEvent('share_tools_opened', {
        shareLinkId: shareLinkId,
        timestamp: new Date().toISOString()
    });
}

function closeShareTools() {
    const workspace = document.getElementById('shareToolsWorkspace');
    workspace.classList.remove('active');
    
    // Auto-save any unsaved changes
    autoSaveDraft();
}

// Platform Tab Management
function switchPlatform(platform) {
    // Hide all content creators
    document.querySelectorAll('.content-creator').forEach(creator => {
        creator.classList.remove('active');
    });
    
    // Show selected platform creator
    document.getElementById(`${platform}-creator`).classList.add('active');
    
    // Update tab appearance
    document.querySelectorAll('.platform-tab').forEach(tab => {
        tab.classList.remove('active');
    });
    document.querySelector(`[data-platform="${platform}"]`).classList.add('active');
    
    // Load platform-specific templates
    loadPlatformTemplates(platform);
}

// Template Management
function selectTemplate(templateType, platform) {
    const templates = {
        facebook: {
            casual: "Hey friends! 👋 Found something really cool that someone in my network might love...",
            professional: "Sharing an interesting opportunity in my professional network...",
            exciting: "🚀 Amazing find! Someone in my network is going to love this...",
            custom: ""
        },
        twitter: {
            casual: "Found something awesome! 🔥",
            professional: "Professional opportunity in my network:",
            exciting: "🚨 This is perfect for someone I know!",
            custom: ""
        }
        // Add other platforms
    };
    
    const messageTextarea = document.querySelector('.message-textarea');
    messageTextarea.value = templates[platform][templateType];
    
    // Update preview
    updatePreview(platform);
    
    // Update character count
    updateCharacterCount();
}

// Real-time Preview Updates
function updatePreview(platform) {
    const message = document.querySelector('.message-textarea').value;
    const previewElement = document.getElementById(`${platform}PreviewText`);
    
    if (previewElement) {
        previewElement.textContent = message;
    }
    
    // Update performance predictions
    updatePerformancePrediction(platform, message);
}

// Performance Prediction AI
async function updatePerformancePrediction(platform, content) {
    try {
        const response = await fetch('/api/sharing/predict-performance', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                platform: platform,
                content: content,
                userId: getCurrentUserId(),
                courseId: getCurrentCourseId()
            })
        });
        
        const prediction = await response.json();
        updatePredictionDisplay(prediction);
        
    } catch (error) {
        console.error('Error predicting performance:', error);
    }
}

// Social Media Posting
async function postToFacebook() {
    const content = {
        message: document.querySelector('.message-textarea').value,
        image: getSelectedImage(),
        audience: getSelectedAudience(),
        trackingLink: getCurrentTrackingLink()
    };
    
    try {
        // Insert tracking link into content
        const finalContent = insertTrackingLink(content.message, content.trackingLink);
        
        // Post to Facebook via API
        const result = await postToSocialMedia('facebook', {
            ...content,
            message: finalContent
        });
        
        // Track successful post
        trackEvent('social_post_created', {
            platform: 'facebook',
            shareLinkId: getCurrentShareLinkId(),
            contentLength: finalContent.length,
            hasImage: !!content.image
        });
// Show success message
       showSuccessToast('🎉 Posted to Facebook successfully! Your tracking link is now live.');
       
       // Update share link status
       updateShareLinkStatus(getCurrentShareLinkId(), 'posted');
       
       // Close share tools
       closeShareTools();
       
       // Redirect to analytics view
       setTimeout(() => {
           window.location.href = `/dashboard/share-links/${getCurrentShareLinkId()}/analytics`;
       }, 2000);
       
   } catch (error) {
       console.error('Error posting to Facebook:', error);
       showErrorToast('Failed to post to Facebook. Please try again.');
   }
}

// Content Optimization Tools
function optimizeForPlatform(platform, content) {
   const optimizations = {
       facebook: {
           maxLength: 500,
           recommendations: [
               'Add emojis for visual appeal',
               'Include a question to encourage engagement',
               'Mention specific benefits'
           ]
       },
       twitter: {
           maxLength: 280,
           recommendations: [
               'Use relevant hashtags',
               'Keep it concise and punchy',
               'Include call-to-action'
           ]
       },
       linkedin: {
           maxLength: 700,
           recommendations: [
               'Professional tone',
               'Mention business value',
               'Tag relevant connections'
           ]
       }
   };
   
   return optimizations[platform];
}

// Auto-save functionality
function autoSaveDraft() {
   const draftData = {
       shareLinkId: getCurrentShareLinkId(),
       platform: getCurrentPlatform(),
       content: document.querySelector('.message-textarea').value,
       selectedImage: getSelectedImage(),
       audience: getSelectedAudience(),
       timestamp: new Date().toISOString()
   };
   
   localStorage.setItem('shareToolsDraft', JSON.stringify(draftData));
}

// Schedule post functionality
function schedulePost() {
   const scheduleModal = `
       <div class="schedule-modal">
           <h3>📅 Schedule Your Post</h3>
           <div class="schedule-form">
               <div class="form-group">
                   <label>Date:</label>
                   <input type="date" id="scheduleDate" min="${new Date().toISOString().split('T')[0]}">
               </div>
               <div class="form-group">
                   <label>Time:</label>
                   <input type="time" id="scheduleTime">
               </div>
               <div class="optimal-times">
                   <h4>🎯 Optimal Times for Your Network:</h4>
                   <button class="optimal-time" onclick="setOptimalTime('09:00')">
                       9:00 AM (High Engagement)
                   </button>
                   <button class="optimal-time" onclick="setOptimalTime('12:00')">
                       12:00 PM (Lunch Break)
                   </button>
                   <button class="optimal-time" onclick="setOptimalTime('18:00')">
                       6:00 PM (After Work)
                   </button>
               </div>
               <div class="schedule-actions">
                   <button onclick="confirmSchedule()">📅 Schedule Post</button>
                   <button onclick="closeScheduleModal()">Cancel</button>
               </div>
           </div>
       </div>
   `;
   
   showModal(scheduleModal);
}
