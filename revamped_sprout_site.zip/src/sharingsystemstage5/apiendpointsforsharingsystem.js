const sharingSystemAPI = {
    
    // Share Intent & Link Creation
    'POST /api/sharing/create-intent': {
        description: 'Create initial sharing intent for a course',
        body: {
            courseId: 'string',
            sharingMethod: 'string', // social_media, email, sms, copy_link
            platform: 'string (optional)', // specific platform if known
            customMessage: 'string (optional)'
        },
        response: {
            shareLinkId: 'string',
            trackingCode: 'string',
            shareUrl: 'string',
            expiresAt: 'datetime'
        }
    },
    
    // Share Links Management
    'GET /api/sharing/my-links': {
        description: 'Get user\'s share links with filtering and pagination',
        parameters: {
            page: 'number',
            limit: 'number',
            filter: 'string (all|active|archived|high-potential)',
            sort: 'string (newest|clicks|performance|potential)',
            search: 'string'
        },
      response: {
           shareLinks: [
               {
                   id: 'string',
                   courseId: 'string',
                   trackingCode: 'string',
                   shareUrl: 'string',
                   courseName: 'string',
                   courseImage: 'string',
                   baconPotential: 'number',
                   status: 'string',
                   createdAt: 'datetime',
                   totalClicks: 'number',
                   conversions: 'number',
                   baconEarned: 'number',
                   performanceRating: 'string' // excellent, good, needs_improvement
               }
           ],
           totalCount: 'number',
           stats: {
               totalActiveLinks: 'number',
               totalClicks: 'number',
               pendingBacon: 'number',
               avgConversionRate: 'number'
           }
       }
   },
   
   // Share Tools & Content Creation
   'GET /api/sharing/share-tools/:shareLinkId': {
       description: 'Load share tools workspace for specific link',
       response: {
           shareLinkData: {},
           courseData: {},
           templates: {
               facebook: [],
               twitter: [],
               linkedin: [],
               instagram: [],
               email: [],
               sms: []
           },
           userHistory: {
               bestPerformingContent: [],
               frequentlyUsedTemplates: [],
               optimalPostingTimes: {}
           }
       }
   },
   
   'POST /api/sharing/generate-content': {
       description: 'Generate platform-specific content using AI',
       body: {
           shareLinkId: 'string',
           platform: 'string',
           template: 'string',
           customMessage: 'string (optional)',
           audience: 'string',
           tone: 'string' // casual, professional, exciting
       },
       response: {
           generatedContent: 'string',
           suggestedHashtags: 'array',
           recommendedImages: 'array',
           performancePrediction: {
               expectedReach: 'number',
               predictedClicks: 'number',
               conversionProbability: 'number'
           },
           optimizationSuggestions: 'array'
       }
   },
   
   'POST /api/sharing/save-draft': {
       description: 'Save content draft for later use',
       body: {
           shareLinkId: 'string',
           platform: 'string',
           content: 'string',
           selectedImage: 'string',
           audience: 'string',
           scheduledFor: 'datetime (optional)'
       },
       response: {
           draftId: 'string',
           savedAt: 'datetime'
       }
   },
   
   // Social Media Posting
   'POST /api/sharing/post-to-platform': {
       description: 'Post content to social media platform',
       body: {
           shareLinkId: 'string',
           platform: 'string',
           content: 'string',
           imageUrl: 'string (optional)',
           audience: 'string',
           scheduledFor: 'datetime (optional)'
       },
       response: {
           shareEventId: 'string',
           platformPostId: 'string',
           postUrl: 'string',
           status: 'string', // posted, scheduled, failed
           estimatedReach: 'number'
       }
   },
   
   'POST /api/sharing/schedule-post': {
       description: 'Schedule post for future publication',
       body: {
           shareLinkId: 'string',
           platform: 'string',
           content: 'string',
           scheduledFor: 'datetime',
           timezone: 'string',
           imageUrl: 'string (optional)',
           audience: 'string'
       },
       response: {
           scheduledShareId: 'string',
           scheduledFor: 'datetime',
           status: 'scheduled'
       }
   },
   
   // Analytics & Tracking
   'GET /api/sharing/analytics/:shareLinkId': {
       description: 'Get comprehensive analytics for share link',
       parameters: {
           timeRange: 'string (24h|7d|30d|90d)',
           granularity: 'string (hourly|daily|weekly)'
       },
       response: {
           overview: {
               totalClicks: 'number',
               uniqueClicks: 'number',
               conversions: 'number',
               conversionRate: 'number',
               baconEarned: 'number',
               performanceTrend: 'string'
           },
           trafficSources: [
               {
                   platform: 'string',
                   clicks: 'number',
                   percentage: 'number',
                   conversionRate: 'number'
               }
           ],
           geographicData: {
               countries: {},
               cities: {},
               mapData: []
           },
           timelineData: [
               {
                   timestamp: 'datetime',
                   clicks: 'number',
                   conversions: 'number'
               }
           ],
           deviceBreakdown: {
               mobile: 'number',
               desktop: 'number',
               tablet: 'number'
           },
           contentPerformance: [
               {
                   platform: 'string',
                   content: 'string',
                   clicks: 'number',
                   conversionRate: 'number',
                   performanceRating: 'string'
               }
           ],
           chainStatus: {
               chainId: 'string',
               currentDegree: 'number',
               potentialEarning: 'number',
               conversionProbability: 'number'
           }
       }
   },
   
   'GET /api/sharing/click-details/:shareLinkId': {
       description: 'Get detailed click tracking data',
       parameters: {
           page: 'number',
           limit: 'number',
           filter: 'string (all|converted|recent)',
           sortBy: 'string (timestamp|location|device)'
       },
       response: {
           clicks: [
               {
                   id: 'string',
                   timestamp: 'datetime',
                   source: 'string',
                   location: 'string',
                   device: 'string',
                   browser: 'string',
                   referrer: 'string',
                   converted: 'boolean',
                   conversionTime: 'datetime',
                   chainPosition: 'number',
                   ipAddress: 'string' // Anonymized
               }
           ],
           totalCount: 'number'
       }
   },
   
   // AI Insights & Optimization
   'GET /api/sharing/ai-insights/:shareLinkId': {
       description: 'Get AI-powered insights and recommendations',
       response: {
           insights: [
               {
                   type: 'string', // optimization, timing, audience, prediction
                   title: 'string',
                   description: 'string',
                   actionable: 'boolean',
                   actionButton: 'string',
                   actionEndpoint: 'string',
                   confidence: 'number' // 0-1
               }
           ],
           performancePrediction: {
               next7Days: {
                   expectedClicks: 'number',
                   conversionProbability: 'number',
                   expectedEarnings: 'number'
               }
           },
           optimizationOpportunities: [
               {
                   area: 'string', // content, timing, platform, audience
                   improvement: 'string',
                   expectedLift: 'number',
                   effort: 'string' // low, medium, high
               }
           ]
       }
   },
   
   // Templates & Content Library
   'GET /api/sharing/templates': {
       description: 'Get available content templates',
       parameters: {
           platform: 'string',
           category: 'string',
           userId: 'string (optional)' // For user-specific templates
       },
       response: {
           systemTemplates: [
               {
                   id: 'string',
                   name: 'string',
                   category: 'string',
                   platform: 'string',
                   content: 'string',
                   successRate: 'number',
                   usageCount: 'number'
               }
           ],
           userTemplates: [],
           popularTemplates: []
       }
   },
   
   'POST /api/sharing/templates': {
       description: 'Create new content template',
       body: {
           name: 'string',
           category: 'string',
           platform: 'string',
           content: 'string',
           hashtags: 'array',
           isPublic: 'boolean'
       },
       response: {
           templateId: 'string',
           createdAt: 'datetime'
       }
   },
   
   // Bulk Operations
   'POST /api/sharing/bulk-share': {
       description: 'Share to multiple platforms simultaneously',
       body: {
           shareLinkId: 'string',
           platforms: [
               {
                   platform: 'string',
                   content: 'string',
                   audience: 'string',
                   scheduledFor: 'datetime (optional)'
               }
           ]
       },
       response: {
           shareEvents: [
               {
                   platform: 'string',
                   status: 'string',
                   shareEventId: 'string',
                   postUrl: 'string'
               }
           ],
           successCount: 'number',
           failureCount: 'number'
       }
   },
   
   'GET /api/sharing/export-data/:shareLinkId': {
       description: 'Export analytics data in various formats',
       parameters: {
           format: 'string (csv|json|xlsx)',
           dataType: 'string (clicks|analytics|performance)',
           timeRange: 'string'
       },
       response: {
           downloadUrl: 'string',
           fileSize: 'number',
           expiresAt: 'datetime'
       }
   }
};
